﻿namespace Stations.Dto.Import
{
    public class SeatsClassPerTrainDto
    {
        public string Name { get; set; }

        public string Abbreviation { get; set; }

        public int? Quantity { get; set; }
    }
}