﻿namespace Stations.Dto.Import
{
    public class SeatingClassDto
    {
        public string Name { get; set; }

        public string Abbreviation { get; set; }
    }
}
