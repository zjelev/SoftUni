﻿using System;

namespace Stealer
{
    class Program
    {
        static void Main(string[] args)
        {
            Spy spy = new Spy();
            // Console.WriteLine(spy.StealFieldInfo("Stealer.Hacker", "username", "password"));
            // Console.WriteLine(spy.AnalyzeAcessModifiers("Stealer.Hacker"));
            Console.WriteLine(spy.RevealPrivateMethods("Stealer.Hacker"));
        }
    }
}
