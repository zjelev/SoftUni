using System;
using System.Linq;
using System.Reflection;
using System.Text;

namespace Stealer
{
    public class Spy
    {
        private Type classType;
        private FieldInfo[] classFields;
        private StringBuilder sb = new StringBuilder();

        public string StealFieldInfo(string investigatedClass, params string[] requestedFields)
        {
            classType = Type.GetType(investigatedClass);
            classFields = classType.GetFields(
                BindingFlags.Instance | BindingFlags.Static | BindingFlags.NonPublic | BindingFlags.Public);
            
            Object classInstance = Activator.CreateInstance(classType, new object[] { });
            
            sb.AppendLine($"Class under investigation: {investigatedClass}");

            foreach (var field in classFields.Where(f => requestedFields.Contains(f.Name)))
            {
                sb.AppendLine($"{field.Name} = {field.GetValue(classInstance)}");
            }

            return sb.ToString().Trim();
        }

        public void AnalyzeAcessModifiers(string className)
        {
            classType = Type.GetType(className);
            classFields = classType.GetFields();
            
        }
    }
}
