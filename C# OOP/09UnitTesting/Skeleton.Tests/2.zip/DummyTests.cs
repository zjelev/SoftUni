﻿using NUnit.Framework;

[TestFixture]
public class DummyTests
{
    private Dummy target;

    [SetUp]
    public void Initialize()
    {
        target = new Dummy(20, 20);
    }

    [Test]
    public void LosesHealthIfAttacked()
    {
        target.TakeAttack(10);

        Assert.That(target.Health, Is.EqualTo(10));
    }

    [Test]
    public void DeadDummyAttacked()
    {
        target.TakeAttack(20);

        Assert.That(() => target.TakeAttack(5),
            Throws.InvalidOperationException.With.Message.EqualTo("Dummy is dead."));
    }

    [Test]
    public void CanGiveXP()
    {
        target.TakeAttack(200);
        Assert.That(target.GiveExperience(), Is.EqualTo(20));
    }

    [Test]
    public void CanNotGiveXP()
    {
         Assert.That(() => target.GiveExperience(),
            Throws.InvalidOperationException.With.Message.EqualTo("Target is not dead."));
    }
}
